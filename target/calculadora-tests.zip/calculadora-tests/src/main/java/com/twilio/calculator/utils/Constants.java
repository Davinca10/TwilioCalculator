package com.twilio.calculator.utils;

public class Constants {
public static final String LOCATION_NUMBER_ONE = "location_number_one";
public static final String LOCATION_NUMBER_TWO = "location_number_two";
}
